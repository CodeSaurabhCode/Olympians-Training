﻿// See https://aka.ms/new-console-template for more information


    async Task PrintHttpStatusasync()
{
    try
    {
        var client = new HttpClient();
        //1.Task based = aggregate
        //var resptask = client.GetAsync("http://www.expired.badssl.com");
        //var response = resptask.Result;
        //2.async await
        var response = await client.GetAsync("http://www.expired.badssl.com");
        Console.WriteLine(response.StatusCode);

    }

    catch (Exception ex)
    {
        Console.WriteLine(ex.GetType());
    }

}
Console.WriteLine("Hello, Async Await");
Console.WriteLine("Prog executing..");
var statustask = PrintHttpStatusasync();

Console.WriteLine("Enter your input");
Console.ReadLine();
