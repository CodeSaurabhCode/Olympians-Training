﻿// See https://aka.ms/new-console-template for more information
using System.Text;

Console.WriteLine("Program is running");
string filename = @"E:\DriveData.txt";
byte[] contents ;


CancellationTokenSource cts  = new CancellationTokenSource();
cts.CancelAfter(5);

try
{
    using (FileStream dataStream = File.Open(filename, FileMode.Open))
    {
        contents = new byte[dataStream.Length];
        await dataStream.ReadAsync(contents, 0, (int)dataStream.Length, cts.Token);
        Console.WriteLine(Encoding.ASCII.GetString(contents));
    }
}
catch(Exception ex)
{
    Console.WriteLine($"Exception type: {ex.GetType()}");
}
finally
{
    cts.Dispose();
}