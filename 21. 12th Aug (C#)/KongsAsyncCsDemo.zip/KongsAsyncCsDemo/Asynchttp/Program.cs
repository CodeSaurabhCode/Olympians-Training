﻿
Console.WriteLine("Hello, Async http!");
Console.WriteLine("Prog executing..");

var client = new HttpClient();

var resptask = client.GetAsync("http://www.skillshare.com");
//var response = resptask.Result;
//Console.WriteLine(response.StatusCode);

//with continuation
resptask.ContinueWith(httptask =>
{
    var response = httptask.Result;
    Console.WriteLine(response.StatusCode);

});


Console.WriteLine("Enter your input");
Console.ReadLine();