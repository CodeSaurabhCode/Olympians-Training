﻿// See https://aka.ms/new-console-template for more information

static void ProcessData()
{
    Console.WriteLine("Process has started..");
    Thread.Sleep(3000);
    Console.WriteLine("Process completed");
}



Console.WriteLine("Hello, Async");
Console.WriteLine("Program Executing..");
//Task.Run(ProcessData);
var task = new Task(ProcessData);
task.Start();
//other tasks/funcs
task.Wait();//blocking
Console.WriteLine("Enter your input:");
Console.ReadLine();
