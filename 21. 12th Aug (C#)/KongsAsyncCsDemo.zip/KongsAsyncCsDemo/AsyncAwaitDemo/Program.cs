﻿// See https://aka.ms/new-console-template for more information

async Task<string>  PrintHttpStatusasync()
{
    var client = new HttpClient();
    var response = await client.GetAsync("http://www.skillshare.com");
   // var response = resptask.Result;
    Console.WriteLine(response.IsSuccessStatusCode);
    return response.ToString();
}



Console.WriteLine("Hello, Async Await");
Console.WriteLine("Prog executing..");
var statustask = PrintHttpStatusasync();

Console.WriteLine("Enter your input");
Console.ReadLine();
