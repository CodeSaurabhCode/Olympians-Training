﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, Async Progress!");

async Task ProcessData(string[] Products,IProgress<int> progress)
{
    for (int i = 0; i < Products.Length; i++)
    {
        progress.Report(i);
        await Task.Delay(1000);
    }
}
Console.WriteLine("Process is running..");
string[] Products = { "Brushes", "Palettes", "Colors", "Canvas" };

IProgress<int> prgReporter = new Progress<int>(i =>
Console.WriteLine($"Processing for product {Products[i]}"));

var dataTask = ProcessData(Products,prgReporter);
Console.WriteLine("Enter input");
await dataTask;