﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NSStructEnum
{
    namespace Countries
    {
        namespace States
        {
            class Karnataka
            {

            }

            namespace Cities
            {
                namespace Bangalore

                 {
                    internal class Customer
                    {
                        public void disp()
                        {
                            Console.WriteLine(" Bangalore Customers");
                        }
                    }
                    

                }
                namespace Chennai
                {
                    public class Customer
                    {
                        public void disp()
                        {
                            Console.WriteLine(" Chennai Customers");
                        }

                    }

                }
            }

        }

    }
    

}

namespace MyNamespace
{

    
}
