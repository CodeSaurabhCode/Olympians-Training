﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace IndexerIterator
{
    internal class Indexer
    {
        public static int arrsize = 5;
        string[] shoplist = new string[arrsize];

        public Indexer() {

            for (int i = 0; i < shoplist.Length; i++)
            {
                shoplist[i] = "____";
            }

        }

        public string this[int index]
        {
            get
            {
                string item;
                if (index >= 0 && index <= arrsize - 1)
                {
                    item = shoplist[index];
                }
                else
                {
                    item = "";
                }
                return item;
            }

            set
            {
                if (index >= 0 && index <= arrsize - 1)
                {
                    shoplist[index] = value;
                }
            }
        }
            //overload indexer

            public int this[string  name]
        {
            get
            {
                int index = 0;
                while(index < shoplist.Length)
                {
                    if(shoplist[index] == name)
                    {
                        return index;
                    }
                    index++;
                }
                return index;
            }
        }






        }
    }

