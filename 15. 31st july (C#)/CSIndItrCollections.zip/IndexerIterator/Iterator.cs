﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerIterator
{
    internal class Iterator
    {
        string[] products = { "Game Console", "Laptops", "Tablets" };
        string[,] prodreviews = new string[3, 2] { { "4", "Good" }, { "3", "Ok" }, { "2", "Not Good" }, };
        int[] price = { 30000, 40000, 500000 };

        //default iterator
        public IEnumerator GetEnumerator()
        {
            for (int i = 0; i < products.Length; i++)
            {
                yield return products[i];
            }
        }




        //named iterator
        public IEnumerable GetReviews()
        {

            for (int i = 0; i < prodreviews.GetLength(0); i++)
            {
                for (int j = 0; j < prodreviews.GetLength(1); j++)
                {
                    yield return prodreviews[i, j];
                }

            }
        }
        public IEnumerable GetPrices()
        {
            for (int i = 0; i < price.Length; i++)
            {
                yield return price[i];
            }
        }

    }

}