﻿namespace IndexerIterator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Indexer!");
            Indexer shopcart = new Indexer();
                    
            //set
            shopcart[0] = "Brushes";
            shopcart[1] = "Watrercolors";
            shopcart[2] = "Palettes";
            shopcart[3] = "Canvas";

            //get
            Console.WriteLine(shopcart[2]);

            for (int i = 0; i < Indexer.arrsize; i++)
            {
                Console.WriteLine(shopcart[i] );

            }

            Console.WriteLine(shopcart["Brushes"]);


            //Iterator
            Console.WriteLine();
            Console.WriteLine( "Iterator Demo" );
            Iterator itr = new Iterator();

            foreach (var item in itr)
            {
                Console.WriteLine(item);

                
            }
            Console.WriteLine();
            //Named iterator
            Console.WriteLine( "Named iterator" );
            foreach (var item in itr.GetPrices())
            {

                Console.WriteLine(item);
            }
            

            Console.WriteLine();
            foreach (var item in itr.GetReviews())
            {

                Console.WriteLine(item);
            }


        }
    }
}