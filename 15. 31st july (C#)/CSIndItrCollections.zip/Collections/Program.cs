﻿using System.Collections;

namespace Collections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Collections!");
            Console.WriteLine( "Array List" );
            ArrList();
            Console.WriteLine();
            Console.WriteLine("Hash Table");
            HashtableColl();
            Console.WriteLine();
            Console.WriteLine("Sorted List");
            SortedListColl();
            Console.WriteLine();
            Console.WriteLine("Generic List");
            ListColl();                
            Console.WriteLine();
            Console.WriteLine("Generic Dictionary");
            DictionaryGen();
        }

        static void ArrList()
        {
            ArrayList al = new ArrayList();
            al.Add(1);
            al.Add("A sunset painting");
            al.Add(true);
            al.Add(new MyClass());

            //Access
            Console.WriteLine( "AL via index" );
            for (int i = 0; i < al.Count; i++)
            {
                Console.WriteLine(al[i] );
            }

            al.Reverse();
            Console.WriteLine(  );
            Console.WriteLine("Reversing the AL"  );
           
            al.Remove(1);
            al.RemoveAt(0);
            //al.RemoveRange(1, 2);

            foreach (var item in al)
            {
                Console.WriteLine(item);
            }

        }

        static void HashtableColl()
        {
            Hashtable ht = new Hashtable();
            ht.Add("P1", "Mobile");
            ht.Add("P2", "PC");
            ht.Add("P3", "Game COnsole");
            ht.Add("P4", "Tablet");

            //1.Display via ICollection
            Console.WriteLine("HT Display via ICOllection ");
            ICollection k = ht.Keys;
            ICollection v = ht.Values;

            foreach (var key in k) 
            {
                Console.WriteLine( $"HT Items -> {key}:{ht[key]}" );
            }
            Console.WriteLine();
            //Dictionary Entry 
            Console.WriteLine( "Ht display via Dictionary" );

            foreach (DictionaryEntry de in ht)
            {
                Console.WriteLine($"HT Items -> {de.Key}:{de.Value}");
            }


        }

        static void SortedListColl()
        {
            SortedList sl = new SortedList();
            sl.Add("P3", "Mobile");
            sl.Add("P2", "PC");
            sl.Add("P4", "Game COnsole");
            sl.Add("P1", "Tablet");

            //1.Display via ICollection
            Console.WriteLine("sl Display via ICOllection ");
            ICollection k = sl.Keys;
            foreach (var key in k)
            {
                Console.WriteLine($"sl Items -> {key}:{sl[key]}");
            }
            Console.WriteLine();
            Console.WriteLine( "Sl via INdex" );
            for (int i = 0; i < sl.Count; i++)
            {
                Console.WriteLine( $"{sl.GetKey(i),5}{sl.GetByIndex(i),10} " );

            }

        }

        //Generic COllection
        static void ListColl()
        {
            List<string> list = new List<string>();
            list.Add("Piano");
            list.Add("Guitar");
            list.Add("Violin");

            for (int i = 0;i < list.Count;i++)
            {
                Console.WriteLine(list[i]);
            }

        }

        static void DictionaryGen()
        {

            Dictionary<int, string> Dt1 = new Dictionary<int, string>();
            Dt1.Add(1, "Narnia");
            Dt1.Add(2, "Harry Potter");
            Dt1.Add(3, "Avatar");

            foreach (KeyValuePair<int,string> item in Dt1)
            {
                Console.WriteLine( $"Key {item.Key} ->  Value {item.Value} " );

            }

            Console.WriteLine();
            Console.WriteLine("Dictionary with Objects");
            Dictionary<int, Movie> MovDictionary = new Dictionary<int, Movie>();
            Movie m1 = new Movie(1, "Narnia");
            Movie m2 = new Movie(2, "Hp");
            Movie m3 = new Movie(3, "Avatar");

            MovDictionary.Add(m1.Mid, m1);
            MovDictionary.Add(m2.Mid, m2);
            MovDictionary.Add(m3.Mid, m3);

            Console.WriteLine("Movie Info via Dictionary Generic");
            foreach(KeyValuePair<int,Movie> item in MovDictionary)
            {
                Console.WriteLine( $"{item.Key} -> Value {item.Value.MName}" );
            }

            







        }
    }

    class MyClass
    {

    }
}