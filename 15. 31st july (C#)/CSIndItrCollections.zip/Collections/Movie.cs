﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
    internal class Movie
    {
        int mid;
        string mname;

        public int Mid { get { return mid; } set { mid = value; } }
        public string MName   { get { return mname; } set { mname = value; } }
        public Movie(int id, string name)
        {
            mid= id;
            mname= name;
            
        }
    }
}
