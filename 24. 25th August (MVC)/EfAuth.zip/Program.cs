using EkamKArtFinal.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllersWithViews();

            builder.Services.AddScoped<ICategoryRepo,CategoryDbRepo>();
            builder.Services.AddScoped<IPaintingRepo, PaintingDbRepo>();
            builder.Services.AddScoped<ShoppingCart>(sp => ShoppingCart.GetCart(sp));
            builder.Services.AddHttpContextAccessor();
            builder.Services.AddSession();
            builder.Services.AddDbContext<PaintingDbContext>(options =>
            options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
            builder.Services.AddDefaultIdentity<IdentityUser>()
                    .AddEntityFrameworkStores<PaintingDbContext>();

builder.Services.AddAuthentication().AddGoogle(
    googleoptions =>
    {
        googleoptions.ClientId = builder.Configuration["Authentication:Google:ClientId"];
        googleoptions.ClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
        });
  

            var app = builder.Build();


            app.UseStaticFiles();
           
            app.UseSession();
           app.UseAuthentication();
            app.UseAuthorization();
            app.MapRazorPages();    
            app.MapDefaultControllerRoute();
            app.UseAuthentication();;
            app.Run();
        
