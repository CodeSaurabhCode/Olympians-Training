﻿using Microsoft.EntityFrameworkCore;

namespace EkamKArtFinal.Models
{
    public class PaintingDbRepo:IPaintingRepo
    {
        private readonly PaintingDbContext _paintingDbContext;

        public PaintingDbRepo(PaintingDbContext paintingDbContext)
        {
            _paintingDbContext = paintingDbContext;
        }

        public IEnumerable<Painting> AllPaintings
        {

            get {
                return _paintingDbContext.Paintings.Include(c => c.Category); 
                    
                  }
        }

        public IEnumerable<Painting> PaintingsOfTheWeek
        {
            get
            {
                return _paintingDbContext.Paintings.Include(c=>c.Category).Where(p=>p.IsPaintingOfTheWeek);
            }
        }


        

        public Painting? GetPaintingById(int paintingId)
        {
            return AllPaintings.FirstOrDefault(p => p.PaintingId == paintingId);
        }

    }
}
