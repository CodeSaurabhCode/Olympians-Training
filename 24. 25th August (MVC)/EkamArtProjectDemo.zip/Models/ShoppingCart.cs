﻿
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace EkamKArtFinal.Models
{
    public class ShoppingCart
    {
        public string ShoppingCartId { get; set; }
        public List<ShoppingCartItem> ShoppingCartItems { get; set; }

        public decimal total { get; set; }

        private readonly PaintingDbContext _paitningDbContext;

        public ShoppingCart(PaintingDbContext paintingDbContext)
        {
            _paitningDbContext = paintingDbContext;
        }

        //Get Cart/Addtocart/Remove cart item/Get shopping items/Clear cart/total

        public static ShoppingCart GetCart(IServiceProvider services) {
                
            ISession? session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext?.Session;

            PaintingDbContext context = services.GetService<PaintingDbContext>() ?? throw new Exception("Error initializing");

            string cartId = session?.GetString("CartId") ?? Guid.NewGuid().ToString();

            session?.SetString("CartId", cartId);

            return new ShoppingCart(context) { ShoppingCartId = cartId };


        }

        public void AddToCart(Painting painting , int qty)
        {
            var shoppingCartItem = _paitningDbContext.ShoppingCartItems.SingleOrDefault(
                s => s.Painting.PaintingId == painting.PaintingId && s.ShoppingCartId == ShoppingCartId);

            if(shoppingCartItem == null) {
                shoppingCartItem = new ShoppingCartItem
                {
                    Painting = painting,
                    ShoppingCartId = ShoppingCartId,
                    Quantity = 1
                };
                _paitningDbContext.ShoppingCartItems.Add(shoppingCartItem);
            }
            else
            {

                shoppingCartItem.Quantity++;

            }
            _paitningDbContext.SaveChanges();
        }

        public List<ShoppingCartItem> GetShoppingCartItems()
        {

            return ShoppingCartItems ??=
                ShoppingCartItems =
                _paitningDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId)
                .Include(s => s.Painting)
                .ToList();
        }

        public decimal GetShoppingCartTotal()
        {
            var total = _paitningDbContext.ShoppingCartItems.Where(c=> c.ShoppingCartId == ShoppingCartId)
                .Select(c=> c.Painting.Price * c.Quantity).Sum();

            return total;
        }



    }
}
