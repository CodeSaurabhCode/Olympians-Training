﻿namespace EkamKArtFinal.Models
{
    public class ShoppingCartItem
    {
        public int ShoppingCartItemId { get; set; }
        public Painting Painting { get; set; }

        public int Quantity { get; set; }

        public string ShoppingCartId { get; set; }
    }
}
