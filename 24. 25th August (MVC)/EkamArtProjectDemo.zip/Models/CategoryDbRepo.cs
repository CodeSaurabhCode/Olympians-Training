﻿namespace EkamKArtFinal.Models
{
    public class CategoryDbRepo:ICategoryRepo
    {
        private readonly PaintingDbContext _paintingDbContext;

        public CategoryDbRepo(PaintingDbContext paintingDbContext)
        {
            _paintingDbContext = paintingDbContext;
            
        }

        public IEnumerable<Category> AllCategories => _paintingDbContext.Categories;
    }
}
