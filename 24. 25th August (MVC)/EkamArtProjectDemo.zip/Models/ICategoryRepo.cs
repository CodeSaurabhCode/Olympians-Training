﻿namespace EkamKArtFinal.Models
{
    public interface ICategoryRepo
    {
        public IEnumerable<Category> AllCategories { get; }
    }
}
