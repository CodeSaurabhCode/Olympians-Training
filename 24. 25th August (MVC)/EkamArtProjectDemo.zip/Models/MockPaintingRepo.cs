﻿namespace EkamKArtFinal.Models
{
    public class MockPaintingRepo:IPaintingRepo
    {
        List<Painting> _paintings;
        private readonly ICategoryRepo _categoryRepository = new MockCategoryRepo();

        public IEnumerable<Painting> AllPaintings {
       
            get { return _paintings; }
        }

        public IEnumerable<Painting> PaintingsOfTheWeek {
            get
            {
                return _paintings;
            }
        }


        public MockPaintingRepo()
        {
            _paintings = new List<Painting>
            {
                new Painting{
                    PaintingId = 1,
                     Name = "Mock Alley",
                     Price = 15000,
                     Description = "A Beautiful painting that can enhance your home space!",
                     CategoryId = 1,
                     ImageUrl = "/images/Alley.jpg",
                     Instock = true,
                     IsPaintingOfTheWeek = false,
                     Category = _categoryRepository.AllCategories.ToList()[0],
                     ImageThumbnailUrl = "/images/Alley.jpg",
                     Tax = 3
                },
                new Painting
                {
                    PaintingId = 2,
                    Name = "Mock Sadhu",
                    Price = 10000,
                    Description = "A Beautiful painting that can enhance your home space!",
                    CategoryId = 2,
                    ImageUrl = "/images/saadhu.jpg",
                    Instock = true,
                    IsPaintingOfTheWeek = false,
                     Category = _categoryRepository.AllCategories.ToList()[1],
                    ImageThumbnailUrl = "/images/saadhu.jpg",
                    Tax = 4

                },


                new Painting
                { PaintingId = 3,
                    Name = "Mock Stairway ",
                    Price = 20000,
                    Description = "A Beautiful painting that can enhance your home space!",
                    CategoryId = 3,
                    ImageUrl = "/images/Well.jpg",
                    Instock = true,
                    IsPaintingOfTheWeek = false,
                     Category = _categoryRepository.AllCategories.ToList()[2],
                    ImageThumbnailUrl = "/images/Well.jpg",
                    Tax = 5
                },
            };
        }

        public Painting? GetPaintingById(int paintingId)
        {
            return AllPaintings.FirstOrDefault(p=>p.PaintingId == paintingId);
        }
    }
}
