﻿namespace EkamKArtFinal.Models
{
    public interface IPaintingRepo
    {
        public IEnumerable<Painting> AllPaintings { get; }
        public IEnumerable<Painting> PaintingsOfTheWeek { get; }
        Painting? GetPaintingById(int paintingId);
    }
}
