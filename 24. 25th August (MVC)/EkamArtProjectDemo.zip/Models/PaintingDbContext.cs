﻿using Microsoft.EntityFrameworkCore;

namespace EkamKArtFinal.Models
{
    public class PaintingDbContext:DbContext
    {
        public PaintingDbContext(DbContextOptions<PaintingDbContext> options):base(options) { }

        public DbSet<Painting> Paintings { get; set; }

        public DbSet<Category> Categories { get; set; }

        public DbSet<ShoppingCartItem> ShoppingCartItems { get; set; }

        public DbSet<Order> Orders { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //seeding the db
            modelBuilder.Entity<Category>().HasData
                (
                new Category
                {
                    CategoryId = 1,
                    CategoryName = "Watercolor",
                    Description = "The most versatile & fresh medium",

                });
            modelBuilder.Entity<Category>().HasData
                (
                new Category
                {
                    CategoryId = 2,
                    CategoryName = "Acrylics",
                    Description = "The most contemperory medium to explore",

                });
            modelBuilder.Entity<Category>().HasData
                (
                new Category
                {
                    CategoryId = 3,
                    CategoryName = "Oils",
                    Description = "The traditional Medium",

                });

            modelBuilder.Entity<Painting>().HasData(

                 new Painting
                 {
                     PaintingId = 1,
                     Name = "King of the Jungle",
                     Price = 45000,
                     Description = "A Beautiful painting that can enhance your home space!",
                     CategoryId = 1,
                     ImageUrl = "/images/Lion.jpg",
                     Instock = true,
                     IsPaintingOfTheWeek = true,
                     ImageThumbnailUrl = "/images/Lion.jpg"
                 });

            modelBuilder.Entity<Painting>().HasData(

          new Painting
          {
              PaintingId = 2,
              Name = "The Tigress",
              Price = 40000,

              Description = "A Beautiful painting that can enhance your home space!",
              CategoryId = 2,
              ImageUrl = "/images/Tiger.jpeg",
              Instock = true,
              IsPaintingOfTheWeek = false,
              ImageThumbnailUrl = "/images/saadhu.jpg"
          });
            modelBuilder.Entity<Painting>().HasData(
           new Painting
           {
               PaintingId = 3,
               Name = "Striped!",
               Price = 50000,

               Description = "A Beautiful painting that can enhance your home space!",
               CategoryId = 3,
               ImageUrl = "/images/Zebra.jpg",
               Instock = true,
               IsPaintingOfTheWeek = false,
               ImageThumbnailUrl = "/images/Zebra.jpg"
           });



            modelBuilder.Entity<Painting>().HasData(
                new Painting
                {
                    PaintingId = 4,
                    Name = "Dotted",
                    Price = 38500,

                    Description = "A Beautiful painting that can enhance your home space!",
                    CategoryId = 2,
                    ImageUrl = "/images/Leopard.jpeg",
                    Instock = true,
                    IsPaintingOfTheWeek = true,
                    ImageThumbnailUrl = "/images/Leopard.jpg"
                });

            modelBuilder.Entity<Painting>().HasData(
                new Painting
                {
                    PaintingId = 5,
                    Name = "The Charmer",
                    Price = 30500,

                    Description = "A Beautiful painting that can enhance your home space!",
                    CategoryId = 2,
                    ImageUrl = "/images/peacock3.jpeg",
                    Instock = true,
                    IsPaintingOfTheWeek = true,
                    ImageThumbnailUrl = "/images/peacock3.jpeg"
                });

            modelBuilder.Entity<Painting>().HasData(
                new Painting
                {
                    PaintingId = 6,
                    Name = "Catcher",
                    Price = 32000,

                    Description = "A Beautiful painting that can enhance your home space!",
                    CategoryId = 1,
                    ImageUrl = "/images/Kingfisher.JPG",
                    Instock = true,
                    IsPaintingOfTheWeek = true,
                    ImageThumbnailUrl = "/images/Kingfisher.png"
                });

            modelBuilder.Entity<Painting>().HasData(
              new Painting
              {
                  PaintingId = 7,
                  Name = "Colored Glitter",
                  Price = 25000,

                  Description = "A Beautiful painting that can enhance your home space!",
                  CategoryId = 1,
                  ImageUrl = "/images/Monal.jpeg",
                  Instock = true,
                  IsPaintingOfTheWeek = true,
                  ImageThumbnailUrl = "/images/Monal.jpeg"
              });

            modelBuilder.Entity<Painting>().HasData(
              new Painting
              {
                  PaintingId = 8,
                  Name = "Among the Green",
                  Price = 35000,
                  Description = "A Beautiful painting that can enhance your home space!",
                  CategoryId = 1,
                  ImageUrl = "/images/Parrot.jpg",
                  Instock = true,
                  IsPaintingOfTheWeek = true,
                  ImageThumbnailUrl = "/images/Parrot.jpg"
              });

            modelBuilder.Entity<Painting>().HasData(
              new Painting
              {
                  PaintingId = 9,
                  Name = "Sunriched",
                  Price = 20000,

                  Description = "A Beautiful painting that can enhance your home space!",
                  CategoryId = 1,
                  ImageUrl = "/images/Sunflowers.png",
                  Instock = true,
                  IsPaintingOfTheWeek = false,
                  ImageThumbnailUrl = "/images/Sunflowers.png"
              });

            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 10,
                 Name = "Red Beauty",
                 Price = 24000,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 1,
                 ImageUrl = "/images/Hibiscus.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = false,
                 ImageThumbnailUrl = "/images/Hibiscus.jpg"
             });

            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 11,
                 Name = "Lotus Love",
                 Price = 28000,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 1,
                 ImageUrl = "/images/lotus3.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = true,
                 ImageThumbnailUrl = "/images/lotus3.jpg"
             });
            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 12,
                 Name = "In the Water",
                 Price = 24000,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 1,
                 ImageUrl = "/images/Lilly.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = false,
                 ImageThumbnailUrl = "/images/Lilly.jpg"
             });
            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 13,
                 Name = "Diagon Alley",
                 Price = 24000,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 1,
                 ImageUrl = "/images/Alley.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = false,
                 ImageThumbnailUrl = "/images/Alley.jpg"
             });
            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 14,
                 Name = "Greece Magic",
                 Price = 28500,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 1,
                 ImageUrl = "/images/Greece.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = false,
                 ImageThumbnailUrl = "/images/Greece.jpg"
             });
            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 15,
                 Name = "At the Shrine",
                 Price = 24000,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 3,
                 ImageUrl = "/images/Well.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = false,
                 ImageThumbnailUrl = "/images/Well.jpg"
             });
            modelBuilder.Entity<Painting>().HasData(
             new Painting
             {
                 PaintingId = 16,
                 Name = "Ethereal View",
                 Price = 25000,

                 Description = "A Beautiful painting that can enhance your home space!",
                 CategoryId = 1,
                 ImageUrl = "/images/Beach.jpg",
                 Instock = true,
                 IsPaintingOfTheWeek = false,
                 ImageThumbnailUrl = "/images/Beach.jpg"
             });

        }


    }

}
