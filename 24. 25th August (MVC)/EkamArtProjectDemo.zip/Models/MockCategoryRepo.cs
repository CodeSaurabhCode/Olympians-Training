﻿namespace EkamKArtFinal.Models
{
    public class MockCategoryRepo:ICategoryRepo
    {
        public IEnumerable<Category> AllCategories =>
           new List<Category>
       {
                new Category{CategoryId=1,CategoryName="Watercolor",Description="The Most varsatile medium"},
                new Category{CategoryId=2,CategoryName="Acrylics",Description="A combo of Oil & Watercolor"},
                new Category{CategoryId=3,CategoryName="Gouache",Description="A new medium , used by contemperory artists"},
       };

      //  IEnumerable<Category> ICategoryRepo.AllCategories { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}
