﻿using EkamKArtFinal.ViewModels;
using EkamKArtFinal.Models;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.CompilerServices;

namespace EkamKArtFinal.Controllers
{
    public class PaintingsController : Controller
    {
        //DI
        private readonly IPaintingRepo _paintingRepo;
        private readonly ICategoryRepo _categoryRepo;

        public PaintingsController(IPaintingRepo paintingRepo, ICategoryRepo categoryRepo)
        {
            _paintingRepo = paintingRepo;
            _categoryRepo = categoryRepo;
        }

        public IActionResult Index(string category)
        {
            IEnumerable<Painting> paintings;
            string currentCategory;

            if (string.IsNullOrEmpty(category))
            {
                paintings = _paintingRepo.AllPaintings.OrderBy(x => x.PaintingId);
                currentCategory = "All Paintings";

            }
            else
            {
                paintings = _paintingRepo.AllPaintings.Where(p => p.Category.CategoryName == category)
                   .OrderBy(p => p.PaintingId);
                currentCategory = _categoryRepo.AllCategories.FirstOrDefault(c => c.CategoryName == category)?.CategoryName;
            }
            return View(new PaintingsListViewModel
            {
                Paintings = paintings,
                CurrentCategory = currentCategory
            });
        }

        public IActionResult Details(int id)
        {
            var painting = _paintingRepo.GetPaintingById(id);
            if (painting == null)
            {
                return NotFound();
            }
            return View(painting);
        }
    }
}
