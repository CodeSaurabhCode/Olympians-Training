﻿using EkamKArtFinal.Models;
using EkamKArtFinal.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EkamKArtFinal.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly IPaintingRepo _paintingRepo;
        private readonly ShoppingCart _shoppingCart;

        public ShoppingCartController(IPaintingRepo paintingRepo, ShoppingCart shoppingCart)
        {
            _paintingRepo = paintingRepo;
            _shoppingCart = shoppingCart;
            
        }
        public IActionResult Index()
        {
            var items = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = items;

            var shoppingviewmodel = new ShoppingCartViewModel()
            {
                ShoppingCart = _shoppingCart,
                ShoppingCartTotal = _shoppingCart.GetShoppingCartTotal(),
            };
            return View(shoppingviewmodel);
        }

        public RedirectToActionResult AddToShoppingCart(int paintingId) {
        var selectedpainting = _paintingRepo.AllPaintings.FirstOrDefault(
            p=> p.PaintingId == paintingId);
            if (selectedpainting != null)
            {
                _shoppingCart.AddToCart(selectedpainting, 1);
            }

            return RedirectToAction("Index");
        }
    }
}
