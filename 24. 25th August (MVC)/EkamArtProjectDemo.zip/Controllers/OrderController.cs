﻿using EkamKArtFinal.Models;
using Microsoft.AspNetCore.Mvc;

namespace EkamKArtFinal.Controllers
{
    public class OrderController : Controller
    {
        public IActionResult CheckOut()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CheckOut(Order order)
        {
            if(ModelState.IsValid)
            {
                return RedirectToAction("CheckoutComplete");
            }
            return View();
        }

        public IActionResult CheckoutComplete()
        {
            ViewBag.ChkoutMsg = "Thanks for your Order! You will soon receive the art & enjoy the paintings adorning your space!";
            return View();
        }

    }
}
