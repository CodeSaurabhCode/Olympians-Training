﻿using EkamKArtFinal.Models;
using EkamKArtFinal.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EkamKArtFinal.Controllers
{
    public class HomeController : Controller
    {
        private readonly IPaintingRepo _paintingRepo;

        public HomeController(IPaintingRepo  paintingRepo)
        {
            _paintingRepo = paintingRepo;
            
        }
        public IActionResult Index()
        {
            var homeViewmodel = new HomeViewModel
            {
                PaintingsofTheWeek = _paintingRepo.PaintingsOfTheWeek
            };
            return View(homeViewmodel);
        }
    }
}
