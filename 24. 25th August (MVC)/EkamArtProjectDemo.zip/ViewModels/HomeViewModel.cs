﻿using EkamKArtFinal.Models;

namespace EkamKArtFinal.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Painting> PaintingsofTheWeek { get; set; }
    }
}
