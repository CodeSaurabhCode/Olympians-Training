﻿using KongsMvcTemplatedemo.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KongsMvcTemplatedemo.Controllers
{
    public class MoviesController : Controller
    {
        // GET: MoviesController
        public ActionResult Index()
        {
            var model = from m in _movieList
                        orderby m.MName
                        select m;

            return View(model);
        }

        // GET: MoviesController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: MoviesController/Create
        public ActionResult Create()
        {
            var movitem = new Movie();
            return View(movitem);
        }

        // POST: MoviesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Movie newmovie)
        {
            try
            {
                _movieList.Add(newmovie);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: MoviesController/Edit/5
        public ActionResult Edit(int id)
        {
            var record = _movieList.Single(m => m.id == id);
            return View(record);
        }

        // POST: MoviesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Movie mov)
        {
            var record = _movieList.Single(m => m.id == id);
            try
            {
                record.MName = mov.MName;
                record.MRating = mov.MRating;

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(record);
            }

        }

        // GET: MoviesController/Delete/5
        public ActionResult Delete(int id)
        {
            var record = _movieList.Single(m => m.id == id);
            return View(record);
        }

        // POST: MoviesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                var record = _movieList.Find(m => m.id == id);
                _movieList.Remove(record);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        static List<Movie> _movieList = new List<Movie>()
        {
        new Movie{
            id = 1,
            MName = "IT",
            MStar = "Pennywise",
            MRating = 4

            },

        new Movie{
            id = 2,
            MName = "Moana",
            MStar = "Dawyne",
            MRating = 3

            },
        new Movie{
            id = 3,
            MName = "Frozen",
            MStar = "Penny",
            MRating = 5

            },
        new Movie{
            id = 4,
            MName = "Avatar 2",
            MStar = "Kate",
            MRating = 4

            }

        };
    }
}
