﻿using KongsMvcTemplatedemo.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace KongsMvcTemplatedemo.Controllers
{
    public class TempDemoController : Controller
    {
        public IActionResult Index()
        {
            Customer customer = new Customer()
            {
                CName = "Raya",
                City = "Malvern"
            };

            string strcust = JsonConvert.SerializeObject(customer);
            TempData["CustInfo"] = strcust;

            return View(@"Home/");
        }
    }
}
