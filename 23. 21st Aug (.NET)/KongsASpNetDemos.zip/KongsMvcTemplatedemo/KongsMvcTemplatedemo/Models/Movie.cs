﻿namespace KongsMvcTemplatedemo.Models
{
    public class Movie
    {
        public int id { get; set; }
        public string MName { get; set; }
        public int MRating { get; set; }
        public string MStar { get; set; }
    }
}
