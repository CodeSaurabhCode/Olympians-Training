﻿namespace KongsMvcTemplatedemo.Models
{
    public class Customer
    {
        public int id { get; set; }
        public string CName { get; set; }
        public string City { get; set; }
    }
}
