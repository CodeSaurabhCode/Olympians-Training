﻿namespace KongsMvcMockDemo.Models
{
    public class MockMovieRepo : IMovieRepo
    {
        List<Movie> _movieList; 
        
        public MockMovieRepo()
        {
            _movieList = new List<Movie>
            {
                new Movie
                {
                    MovieId = 1,
                    Name = "Avatar",
                    MovieStar = "Tom",
                    IsMovieofTheWeek = true,
                    Rating = 4,
                     CategoryId = 1,
                     Price = 100

                },
                new Movie
                {
                    MovieId = 2,
                    Name = "Airport",
                    MovieStar = "Tom",
                    IsMovieofTheWeek = false,
                    Rating = 3,
                     CategoryId = 2,
                     Price = 100

                },
                new Movie
                {
                    MovieId = 1,
                    Name = "Avatar 2",
                    MovieStar = "Kate",
                    IsMovieofTheWeek = true,
                    Rating = 4,
                     CategoryId = 3,
                     Price = 200

                }
            };
            
        }



        public IEnumerable<Movie> AllMovies
        {
            get { return _movieList; }
        }
        public IEnumerable<Movie> MoviesoftheWeek
        { get { return _movieList; } }

        public Movie GetMovieById(int movieid)
        {
            return AllMovies.FirstOrDefault(m => m.MovieId == movieid);
        }
    }
}
