﻿namespace KongsMvcMockDemo.Models
{
    public interface IMovieRepo
    {
        public IEnumerable<Movie> AllMovies { get;  }
        public IEnumerable<Movie> MoviesoftheWeek { get;  }

        Movie GetMovieById(int Movieid);
    }
}
