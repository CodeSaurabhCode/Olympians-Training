﻿namespace KongsMvcMockDemo.Models
{
    public class MockCategoryRepo : ICategoryRepo
    {
        public IEnumerable<Category> GetAllCategories => new List<Category>
        {
            new Category
            {
                CategoryId = 1,
                CategoryName = "Sci Fi",
                 Description = "All the science fiction ..",
            },
            new Category
            {
                CategoryId = 2,
                CategoryName = "Action",
                 Description = "All the Action & drama ..",
            },
            new Category
            {
                CategoryId = 3,
                CategoryName = "Horror",
                 Description = "All the Horror & Mystery..",
            },
        };
    }
}
