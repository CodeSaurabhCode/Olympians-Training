﻿namespace KongsMvcMockDemo.Models
{
    public interface ICategoryRepo
    {
        public IEnumerable<Category> GetAllCategories { get; }
    }
}

