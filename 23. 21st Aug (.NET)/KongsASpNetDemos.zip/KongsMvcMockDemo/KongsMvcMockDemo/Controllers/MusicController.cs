﻿using Microsoft.AspNetCore.Mvc;

namespace KongsMvcMockDemo.Controllers
{
    public class MusicController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Welcome()
        {
            return View();
        }

        public IActionResult MusicPg()
        { return View(); }
    }
}
