﻿using KongsMvcMockDemo.Models;
using Microsoft.AspNetCore.Mvc;

namespace KongsMvcMockDemo.Controllers
{
    //[Route("emovies/[controller]/[action]")]
    public class MovieController : Controller
    {
        //DI
        private IMovieRepo _movieRepo;
        private ICategoryRepo _categoryRepo;

        //Service injection
        public MovieController(IMovieRepo movieRepo,ICategoryRepo categoryRepo)
        {
            _movieRepo = movieRepo;
            _categoryRepo = categoryRepo;
            
        }

        [Route("")]
        [Route("Movie/")]
        [Route("Movie/Index")]
        [Route("Movie/Index/{id:int}")]
        // GET: MoviesController
        public IActionResult Index(int category)
        {
            IEnumerable<Movie> movies;
            string currentCatergory;

           
                movies = _movieRepo.AllMovies.OrderBy(m => m.Name);
                currentCatergory = "All Movies";
           
            return View(movies);
        }
    }
}
