﻿namespace KongsRazorDemo.Models
{
    public class ProductItem
    {
        public string Product { get; set; }
        public string Rating { get; set; }
    }
}
