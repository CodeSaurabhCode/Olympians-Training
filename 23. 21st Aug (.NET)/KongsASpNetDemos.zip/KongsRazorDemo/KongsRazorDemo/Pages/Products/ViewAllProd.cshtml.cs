using KongsRazorDemo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Text.Json;

namespace KongsRazorDemo.Pages.Products
{
    public class ViewAllProdModel : PageModel
    {
        public List<ProductItem> ProductList { get; set; }
        public void OnGet()
        {
            var jsoncontent = System.IO.File.ReadAllText("wwwroot/sampledata/products.json");
            ProductList = JsonSerializer.Deserialize<List<ProductItem>>(jsoncontent);

        }
    }
}
