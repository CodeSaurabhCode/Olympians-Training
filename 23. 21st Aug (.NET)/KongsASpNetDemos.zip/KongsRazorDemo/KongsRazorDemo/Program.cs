var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

var app = builder.Build();

// Configure the HTTP request middleware pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseWelcomePage(new WelcomePageOptions
{
    Path = "/Welcome"
});
//log info
app.UseHttpLogging();
//secure
app.UseHttpsRedirection();
//wwwroot
app.UseStaticFiles();
//enable navigation
app.UseRouting();
//auth
app.UseAuthorization();
app.UseStatusCodePagesWithRedirects("/Error");
//razor routing
app.MapRazorPages();

app.Run();
