﻿namespace AttribDemo
{
    [Custom(CustomInfo = " Attribute for the class")]
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Attributes!");
            Movie movie = new Movie();
            movie.REview();
        }


    }

    class Movie
    {
        [Custom(CustomInfo = " Attribute for the class")]
        public int Id { get; set; }

        [Obsolete("This is becoming old..use the new method")]
        [Custom(CustomInfo = " Attribute for the class")]
        public string REview()
        {
            return "Movie review function";
        }

        
        public string MREview()
        {
            return "New Movie review function";
        }


    }
}