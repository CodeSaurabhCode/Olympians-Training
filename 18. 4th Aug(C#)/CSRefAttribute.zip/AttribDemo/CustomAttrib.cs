﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttribDemo
{
    [AttributeUsage(AttributeTargets.All)]
    public class CustomAttribute:Attribute
    {
        public string CustomInfo { get; set; }
    }
}
