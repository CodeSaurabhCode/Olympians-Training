﻿using System.Reflection;
using System.Windows.Markup;

namespace Reflections
{
    internal class Program
    {
        public int Prop1 { get; set; }
        public string Prop2 { get; set; }
        static void Main(string[] args)
        {

            Console.WriteLine("Hello, Reflection!");
            Console.WriteLine( "Active Assembly members" );
            assemblyInfo();
            Console.WriteLine();

            Console.WriteLine("Methods of PRogram");
            MemberMethodInfo();
            Console.WriteLine();

            Movie mov = new Movie();
            mov.Actorid = 1;
            mov.Actorname = "Rajni";
            Type type = typeof(Movie);

            //Constructor Info
            Type movtype = typeof(Movie);
            ConstructorInfo constructorInfo = movtype.GetConstructor(Type.EmptyTypes);
            if (constructorInfo != null)
            {
                Console.WriteLine("Constructor Invocation");
                //Create an instance of Movie
                object instance = constructorInfo.Invoke(null);
                MethodInfo methodInfo = movtype.GetMethod("rating");
                Console.WriteLine(methodInfo.Invoke(instance,new object[] {20}));


            }





            foreach (PropertyInfo item in type.GetProperties())
            {
                object value = item.GetValue(mov, null);
                string name = item.Name;

                if (value is int)
                {
                    Console.WriteLine($"Int {name}, {value}");

                }

                else if(value is string)
                {
                    Console.WriteLine($"String {name}, {value}");
                }
                
            }

        }

        public static void disp()
        {
            Console.WriteLine("method1");
        }

        public static void disp2()
        {
            Console.WriteLine("method2");
        }
        /// <summary>
        /// This is a document for reflection..
        /// </summary>
        public static void assemblyInfo()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            Type[] assemblytypes = assembly.GetTypes();

            foreach (var item in assemblytypes)
            {
                Console.WriteLine(item.Name);
            }
        }

        public static void MemberMethodInfo()
        {
            Type type = typeof(Program);
            foreach (var item in type.GetMethods())
            {
                Console.WriteLine(item.Name);

            }
        }
    }

    class Movie
    {
        //fields
        private int id =1;
        private string actornm;

        //props
        public int Actorid { get; set; }
        public string Actorname { get { return actornm; } set { actornm = value; } }

        //methods
        public int rating(int n1)
        {
            return id+ n1;
        }

    }

    struct MyStruct
    {

    }

    enum MyEnum { }

    namespace MyNamespace
    {

    }

    interface IInterface
    {

    }
}