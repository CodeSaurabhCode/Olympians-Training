using FizzBuzzDemo;

namespace KongsTestNunit
{
    ///Fizzbuzz
    /// <summary>
    /// 1. If it is 3 -> Fizz
    /// 2. If the number input is 5 -> return Buzz
    /// 3.If the number is a multiple of 3 & 5 - > return Fizzbuzz
    /// 4.If any other number - > return the number
    /// 1, 2 , Fizz, 4, Buzz, Fizz, 7, 8,Fizz,Buzz, 11,Fizz,13,14,Fizzbuzz
    /// </summary>estFixture]
    public class Tests
    {
        int i;
        [SetUp]
        public void firstCall()
        {
            i = 10;
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }

        [Test]
        public void Test2()
        {
            Assert.Fail();
        }

        [Test]
        [Ignore("Will check later..")]
        public void Test3() { 
            Assert.Fail();
        }

        [Test]
        public void Given1return1()
        {
            //Arrange
            int input = 1;
            //Act
            string op = FizzBuzz.Get(input); 
            //Assert
            Assert.AreEqual("1", op);
        }

        [Test]
        public void Given3returnFizz([Values(3,6,9,12,18)] int input)
        {
            //Arrange
            //int input;
            //Act
            string op = FizzBuzz.Get(input);
            //Assert
            Assert.AreEqual("Fizz", op);
        }

        [Test]
        public void Given5returnBuzz([Values(5,10,20)] int input)
        {
            //Arrange
            //int input;
            //Act
            string op = FizzBuzz.Get(input);
            //Assert
            Assert.AreEqual("Buzz", op);
        }

        [TearDown]
        public void Cleanup()
        {
            i = 0;
        }
    }
}