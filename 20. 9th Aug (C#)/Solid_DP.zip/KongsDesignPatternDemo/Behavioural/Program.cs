﻿namespace Behavioural
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Behavioural Patterns!");
            Console.WriteLine("Template Pattern");
            Animal ani1 = new Tiger();
            Animal ani2 = new Fox();
            ani1.eat();
            ani1.hunt();
            ani2.eat();
            ani2.hunt();
            Console.WriteLine();
            
            Console.WriteLine("Startegy");
            Calculate calc = new Calculate();
            calc.setNumber(80);
            calc.setDouble(new Addition());
            Console.WriteLine(calc.doDouble());
            calc.setNumber(20);
            calc.setDouble(new Multiply());
            Console.WriteLine(calc.doDouble());

        }
    }

    //Template pattern
    abstract class Animal
    {
        public string name;
        public abstract void eat();
        public abstract void hunt();

    }

    class Tiger : Animal
    {
        public override void eat()
        {
            Console.WriteLine("Tiger eats other animals");
        }

        public override void hunt()
        {
            Console.WriteLine("Tiger hunts deers, zebras..");
        }
    }

    class Fox : Animal
    {
        public override void eat()
        {
            Console.WriteLine("Fox eats leftovers");
        }

        public override void hunt()
        {
            Console.WriteLine("Fox scavenges..");
        }
    }

    //Strategy Pattern
    abstract class Double
    {

        public abstract int doSum(int a);

    }

    class Addition : Double
    {
        public override int doSum(int a)
        {
            return a + a;
        }

    }


    class Multiply : Double
    {
        public override int doSum(int a)
        {
            return a * a;
        }

    }

    class Calculate
    {
        int number;
        Double _double;

        public void setDouble(Double d)
        {
            _double = d;
                    
        }

        public void setNumber(int a)
        {
            number = a;
        }

        public int doDouble()
        {
            return _double.doSum(number);
        }


    }

}