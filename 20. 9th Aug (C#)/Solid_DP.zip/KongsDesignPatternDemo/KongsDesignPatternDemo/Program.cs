﻿using System.Transactions;

namespace KongsDesignPatternDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Patterns!");
            Console.WriteLine("Singleton Class");
            
            //  SingletonDemo sobj = new SingletonDemo();
            Console.WriteLine("Singleton - Creational");
            SingletonDemo sobj = SingletonDemo.CreateInstance();
            sobj.setName ( "App1");
            Console.WriteLine(sobj.getName());
            SingletonDemo sobj2 = SingletonDemo.CreateInstance();
            sobj2.setName("App2");
            Console.WriteLine(sobj2.getName());
            Console.WriteLine(sobj.getName());
            Console.WriteLine(sobj == sobj2);
            Console.WriteLine( );
            
            Console.WriteLine("Creational - Prototype");
            BookingType seat1 = new Booking();
            seat1.setSeat("12B");
            Console.WriteLine(seat1.getSeat());
            BookingType seat2 = seat1.clone();
            Console.WriteLine( seat2.getSeat() );



        }
    }



    //Creational - Singelton - creating a single instance to be shared
   public class SingletonDemo
    {

        private static SingletonDemo _instance;
        private string name = " My Singleton Class";

        public string getName()
        {
            return name;
        }

        public void setName(string nm)
        {
            name = nm;
        }
        protected SingletonDemo() { }

        public static SingletonDemo CreateInstance()
        {
            if(_instance == null)
            {
                _instance = new SingletonDemo();
            }
            return _instance;
        }


    }

    //Prototype - to clone or copy the object/prototype to extend
    abstract class BookingType
    {
        private string mSeat;
        public void setSeat(string s)
        {
            mSeat = s;
        }

        public abstract BookingType clone();

        public string getSeat()
        {
            return mSeat ;
        }
    }

    class Booking : BookingType
    {
        public override BookingType clone()
        {
            return this.MemberwiseClone() as BookingType;
        }
    }



}