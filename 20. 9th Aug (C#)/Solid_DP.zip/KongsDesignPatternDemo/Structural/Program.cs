﻿namespace Structural
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Structural Patterns!");
            Console.WriteLine("Proxy pattern");
            BankProxy bkprxy = new BankProxy();
            bkprxy.balancecheck();
            bkprxy.deposit();
            bkprxy.withdrawal();
                        
            Console.WriteLine("Adapter Pattern");
            India india = new India(new WorkAbroad());
            Console.WriteLine(india.startWork());
        }
    }

    //Proxy pattern
    interface IBank
    {
        string withdrawal();
        void deposit();
        void balancechk();
    }

    class Bank : IBank
    {
        public void balancechk()
        {
            Console.WriteLine( "Balance is loww.. " );
        }

        public void deposit()
        {
            Console.WriteLine("DEpositing..");
        }

        public string withdrawal()
        {
            return "Withdrawing";
        }
    }

    class BankProxy
    {
        private Bank bank = new Bank();

        public string withdrawal()
        {
            return bank.withdrawal();
        }

        public void deposit()
        {
            bank.deposit();
        }

        public void balancecheck()
        {
            bank.balancechk();
        }
    }

    //Adapter pattern
    interface IWorkAbroad
    {
        string doWork();
    }
    
    class India
    {
        private readonly IWorkAbroad workAbroad;

        public India(IWorkAbroad work)
        {
            workAbroad = work;
            
        }

        public string startWork()
        {
            return workAbroad.doWork();
        }
    }

    class China
    {
        public string workHere()
        {
            return "You are now working in CHina";
        }
    }

    class WorkAbroad : IWorkAbroad
    {
        readonly China china = new China();
        public string doWork()
        {
            return china.workHere();
        }
    }















}