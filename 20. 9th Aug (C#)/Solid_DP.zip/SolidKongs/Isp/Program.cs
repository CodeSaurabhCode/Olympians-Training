﻿namespace Isp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

        }
    }

    public interface IOrder
    {
        void AddToCart();
        void CCProcess();
    }

    public class OnlineOrder : IOrder
    {
        public void AddToCart()
        {
            //Do Add to Cart
        }

        public void CCProcess()
        {
            //process through credit card
        }
    }

    public class OfflineOrder : IOrder
    {
        public void AddToCart()
        {
            //Do Add to Cart
        }

        public void CCProcess()
        {
            //Not required for Cash/ offline Order
            throw new NotImplementedException();
        }
    }


    //Refactored

    public interface IOrder1
    {
        void AddToCart();
    }

    public interface IOnlineOrder1
    {
        void CCProcess();
    }

    public class OnlineOrder1 : IOrder1, IOnlineOrder1
    {
        public void AddToCart()
        {
            //Do Add to Cart
        }

        public void CCProcess()
        {
            //process through credit card
        }
    }

    public class OfflineOrder1 : IOrder1
    {
        public void AddToCart()
        {
            //Do Add to Cart
        }
    }
}