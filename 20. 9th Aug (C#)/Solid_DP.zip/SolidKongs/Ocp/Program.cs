﻿namespace Ocp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    class Animals
    {
        public int id { get; set; }
        public string habit { get; set; }


        public void eat(string atype)
        {

            if (atype == "Herbivore")
            {
                habit = "No meat";
            }

            else if(atype == "Carnivore")
            {
                habit = "Meat";
            }

            else if(atype == "Omnivore")
            {
                habit = "Eats meat & plants";
            }
        }
    }


    //Refactored

    interface IAnimal
    {

        public int id { get; set; }
        public string habit { get; set; }


        public void eat(string atype)
        {
        }
    }

    class Carnivore : IAnimal
    {
        public int id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string habit { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }

    class Herbivore : IAnimal
    {
        public int id { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public string habit { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }



    public class BAccount
    {
        public decimal Interest { get; set; }
        public decimal Balance { get; set; }
        // members and function declaration
        public decimal CalcInterest(string accType)
        {

            if (accType == "Regular") // savings
            {
                Interest = (Balance * 4) / 100;
                if (Balance < 1000) Interest -= (Balance * 2) / 100;
                if (Balance < 50000) Interest += (Balance * 4) / 100;
            }
            else if (accType == "Salary") // salary savings
            {
                Interest = (Balance * 5) / 100;
            }
            else if (accType == "Corporate") // Corporate
            {
                Interest = (Balance * 3) / 100;
            }
            return Interest;
        }
    }


    //Refactored

    interface IAccount
    {
        // members and function declaration, properties
        decimal Balance { get; set; }
        decimal CalcInterest();
    }

    //regular savings account 
    public class RegularSavingAccount : IAccount
    {
        public decimal Balance { get; set; } = 0;
        public decimal CalcInterest()
        {
            decimal Interest = (Balance * 4) / 100;
            if (Balance < 1000) Interest -= (Balance * 2) / 100;
            if (Balance < 50000) Interest += (Balance * 4) / 100;

            return Interest;
        }
    }

    //Salary savings account 
    public class SalarySavingAccount : IAccount
    {
        public decimal Balance { get; set; } = 0;
        public decimal CalcInterest()
        {
            decimal Interest = (Balance * 5) / 100;
            return Interest;
        }
    }

    //Corporate Account
    public class CorporateAccount : IAccount
    {
        public decimal Balance { get; set; } = 0;
        public decimal CalcInterest()
        {
            decimal Interest = (Balance * 3) / 100;
            return Interest;
        }
    }

    //OCP
    public abstract class Assignment
    {
        public int assignmentId { get; set; }
        public string title { get; set; }
        public double possiblePoints { get; set; }

        public abstract void CalculateGrades();
    }

    public class EssayAssignment : Assignment
    {
        public override void CalculateGrades()
        {
            //code to calculate assignment grade
            Console.WriteLine("EssayAssignment Grades");
        }
    }


    public class ReadingAssignment : Assignment
    {
        public override void CalculateGrades()
        {
            Console.WriteLine("ReadingAssignment Grades");
        }
    }


    public class ProgrammingAssignment : Assignment
    {
        public override void CalculateGrades()
        {
            Console.WriteLine("ProgrammingAssignment Grades");
        }
    }

}