﻿using System.ComponentModel.DataAnnotations;
using System.Net.Mail;

namespace SolidKongs
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }

    public class UserSvc
    {
        public void Register(string email, string password)
        {

            SendEmail(new MailMessage("ekam@soa.com", email) 
            { Subject = "hey! there" });
        }
        public virtual bool ValidateEmail(string email)
        {
            return email.Contains("@");
        }
        public bool SendEmail(MailMessage message)
        {
            return true;
        }
    }


    //Segragate

    public class EmailSvc
    {
        SmtpClient _smtpClient;
        public EmailSvc(SmtpClient aSmtpClient)
        {
            _smtpClient = aSmtpClient;
        }
        public bool ValidateEmail(string email)
        {
            return email.Contains("@");
        }
        public bool SendEmail(MailMessage message)
        {
            return true;
        }
    }
}