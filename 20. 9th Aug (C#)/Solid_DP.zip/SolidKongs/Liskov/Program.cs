﻿namespace Liskov
{
   


    namespace Demo
    {
        public class Program
        {
            static void Main(string[] args)
            {
                Triangle triangle = new Circle();
                //Console.WriteLine(triangle.GetColor());


                //Refactored
                Painting shape = new Watercolor();
                Console.WriteLine(shape.GetColors());
                shape = new Acrylics();
                Console.WriteLine(shape.GetColors());


            }
        }

        public class Triangle
        {
            public virtual string GetShape()
            {
                return "Triangle";
            }
        }

        public class Circle : Triangle
        {
            public override string GetShape()
            {
                return "Circle";
            }
        }

        //Refactored

        public abstract class Painting
        {
            public abstract string GetColors();
        }

        public class Watercolor : Painting
        {
            public override string GetColors()
            {
                return "Triangle";
            }
        }

        public class Acrylics : Painting
        {
            public override string GetColors()
            {
                return "Circle";
            }
        }
    }
}