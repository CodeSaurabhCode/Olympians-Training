export interface IMovies{
    movieID:number;
    movieName:string;
    movieStar:string;
    movieRating:number;
    movieGenre:string;
    movieImg:string;
   
}