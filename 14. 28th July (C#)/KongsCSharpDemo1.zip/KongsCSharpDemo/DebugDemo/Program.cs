﻿namespace DebugDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Debug!");

            int x =10, y =20,z=30;
            int res = x * y * z;
            Console.WriteLine(res);

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine(i);
            }
            disp();
            disp2();

        }

        static void disp()
        {
            int k = 50;
            Console.WriteLine("Debugging is on..");
        }

        static void disp2()
        {
            int j = 50;
            Console.WriteLine("At disp 2");
        }
    }
}