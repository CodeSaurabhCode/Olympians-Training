﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsKDemo
{
    class MyClass2
    {
        
    }
    class MyClass
    {
        public MyClass()
        {
            Console.WriteLine("From the parent of customer");
        }
    }

    internal class Customer:MyClass
    {
        //Data members
        //Fields,Props,constructors,

        //private - Access specifiers
        int id;
        public string name;
        string city = "Chennai";

        //read & write
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public virtual void CustDisp()
        {
            Console.WriteLine($"Customer name is {name} & is from {city} & the id is {id}");
        }

        //Constructor
        public Customer()
        {
            Console.WriteLine("From Parent default constructor");
            name = "Marla";
            id = 1;

        }

        //constructor overloading
        //parameterized constructor
        public Customer(int ID, string nm, string cty)
        {
            
            id = ID;
            name = nm;
            city = cty;

        }

        public Customer(int custid)
        {
            id = custid;
            
        }

        //destructor

        ~Customer()
        {
            Console.WriteLine( "Destructor invoked for customer" );
        }

        //method overloading - polymorphism - static/compile
        //function signature - params - no, order, data type - does not inlcude return type
        public void Add()
        {
            int n1 = 10, n2 = 20;
            Console.WriteLine(n1 + n2);
        }

        public void Add(float n1, int n2)
        {
            Console.WriteLine( n1++ );
            Console.WriteLine(n1 + n2);

        }

        public void Add(int n1, float n2)
        {
            Console.WriteLine(n1 + n2);
        }

        //public int Add(int n1, float n2)
        //{
        //    Console.WriteLine(n1 + n2);
        //    return n1;
        //}


    }

    interface IBank
    {
        
        public int BankID { get; set; }
        void Idisp();
     
      }

    public abstract class BankingCustomer
    {
        int id;
        public int ID { get; set; }

        public void BankDisplay()
        {
            Console.WriteLine("Abstract class regular method");
        }

        public abstract void BankInfo();
    }



    interface MyInterface
    {
        
    }
    class Bank : BankingCustomer,IBank, MyInterface
    {
        public int BankID 
        { get; set; }

        public override void BankInfo()
        {
            Console.WriteLine("Overriding the abstract method in parent..");
        }

        public void Idisp()
        {
            Console.WriteLine(  "From the interface");
        }
    }



    sealed class  AsianCustomer : Customer
    {
        public AsianCustomer()
        {
            Console.WriteLine("From Child constructor");
        }

        public override void CustDisp()
        {
            base.CustDisp();
            Console.WriteLine(  "Overriding the parent customer in asia");
        }

        ~AsianCustomer()
        {
            Console.WriteLine( "Destructing from Asian customer" );
        }

    }

    //Cannot derive from sealed
    //class Japan:AsianCustomer
    //{
    
    //}

    //static class - cannot derive or instantiate
    static class Products
    {
        static int i;

        public static void prodisp()
        {
            Console.WriteLine(  "From Static prod");
        }

    }


    //class class1 : Products
    //{

    //}

    partial class Buyer
    {
        int id;
        public int ID { get { return id; } }


         public void disp1()
        {
            Console.WriteLine("From regular method");
        }

        public partial void disp2();

    }



    
    
}
