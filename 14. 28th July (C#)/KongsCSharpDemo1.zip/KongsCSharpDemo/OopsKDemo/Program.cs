﻿namespace OopsKDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Oops Demo!");
            Customer c1 = new Customer();
            Customer c2 = new Customer(10);
            Customer c3 = new Customer(2,"Patricia","NY");
            Console.WriteLine(  );
            //Inheritance
            c1.name = "Riya";
            c1.City = "Sacramento";
            Console.WriteLine(c1.City);
            c1.CustDisp();
            c3.CustDisp();
            Console.WriteLine(  );
            c2.Add();
            c2.Add(30, 60f);
            c2.Add(1f, 2);

            Console.WriteLine(  );
            //Abstract Class & Interface
            Console.WriteLine( "From Child class" );
            AsianCustomer asianCustomer = new AsianCustomer();
            asianCustomer.CustDisp();

            Bank bobj = new Bank();
            bobj.BankDisplay();
            bobj.Idisp();
            bobj.BankInfo();

            ////cannot create an abstract clas obj
            //BankingCustomer bankingCustomer = new BankingCustomer();

            Console.WriteLine("Static ");
            ////Static clas - no object
            //Products prod = new Products();
            Products.prodisp();

            Console.WriteLine( "Partial classes" );
            //Partial class
            Buyer buyer = new Buyer();
            buyer.disp1();
            buyer.disp2();
            buyer.disp3();

           

            
        }
    }
}