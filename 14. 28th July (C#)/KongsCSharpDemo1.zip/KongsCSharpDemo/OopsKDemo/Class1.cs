﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OopsKDemo
{
    partial class Buyer
    {
        public void disp3()
        {

        }
        public partial void disp2()
        {
            Console.WriteLine( "Function definition from another file" );
        }
    }
}
