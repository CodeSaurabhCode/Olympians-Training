﻿

namespace KongsCSharpDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int age;
            //i = 10;
            string name;
            Console.WriteLine("Enter your name");
            name = Console.ReadLine();
            Console.WriteLine("Enter your age");
            age = Convert.ToInt32(Console.ReadLine());

            //display formatting
            //1. + concatenation operator  
            Console.WriteLine("Hello, " + name + "Your age is " + age);
            //2.placeholders
            Console.WriteLine("Hello,  {0}  Your age is {1} ", name, age);
            //3.String interpolation
            Console.WriteLine($"Hello,  {name}  Your age is {age} ");

            //Constructsdemo();
            ArrDemo();
        }

        //COnstructs demo
        public static void Constructsdemo()
        {
            string dept;
            Console.WriteLine("Enter the dept name");
            dept = Console.ReadLine();
            int sal = 50000;

            if(dept == "IT")
            {
                sal = sal + 10000;
                goto salary;
            }
            else
            {
                Console.WriteLine("Sorry ! no bonus");
            }
            Console.WriteLine(  "If demo..");
            salary:
            Console.WriteLine("yay! got the bonus "  );
            Console.WriteLine("Emp sal is " + sal  );

            //while
            int x = 0;
            while(x < 10)
            {
                Console.WriteLine(x);
                x++;
            }

            for(int i = 0; i < 10; i++)
            {
                Console.WriteLine(i);
            }

            //do { Console.WriteLine()}

            //switch (choice)
            //{
            //    default:
            //        break;
            //}

            int[] arr1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
            foreach(int i in arr1)
            {
                Console.WriteLine(i);
            }

        }

        public static void ArrDemo()
        {
            //single dimension
            int[] arr1 = { 1, 2, 3, 4, 5, 6 };
            string[] florals = { "Rose", "Tulips", "Orchids" };

            Console.WriteLine("Single Dimension");
            for (int i = 0; i < arr1.Length; i++)
            {
                Console.WriteLine(arr1[i]);

            }

            foreach(var i in florals)
            {
                Console.WriteLine(i);
            }
            Array.Sort(arr1);
            Array.Reverse(florals);
            foreach (var i in florals)
            {
                Console.WriteLine(i);
            }
            int[,] arr2 = { { 1, 2 }, { 3, 4 }, { 5, 6 } };
            int[,,] arr3 = { { { 1, 2 } },
                             { { 2, 3 } }, 
                             { { 50, 60 } } };

            int d1 = arr3.GetLength(0);
            int d2 = arr3.GetLength(1);
            int d3 = arr3.GetLength(2);

            Console.WriteLine("Multi Dimension");
            for (int i = 0; i < d1; i++)
            {
                for (int j = 0; j < d2; j++)
                {
                    for (int k = 0; k < d3; k++)
                    {
                        Console.WriteLine(arr3[i, j, k] + " ");

                    }
                }
            }

            Console.WriteLine(arr1.Rank);
            Console.WriteLine(arr3.Rank);


            //Jagged Array -Array of Arrays -Varying Column lengths

            int[][] jarr = new int[3][];
            jarr[0] = new int[3];
            jarr[1] = new int[2];
            jarr[2] = new int[1];

            jarr[0] = new int[] { 1, 2, 3 };
            jarr[1] = new int[] { 1, 2 };
            jarr[2] = new int[] { 1 };

            //shortcut
            int[][] jarr2 =
            {
                new int[] { 1,2, 3 },
                new int[] { 1, 2},
                new int[] { 1}

            };

            Console.WriteLine("Jagged Array");
            for (int i = 0; i < jarr2.Length; i++)
            {
                Console.WriteLine("Element({0}):",i+1);
                for (int j = 0; j < jarr2[i].Length; j++)
              
                {
                    Console.WriteLine($"{jarr2[i][j],3}"  );

                }
                Console.WriteLine();
            }











        }
    }
}