﻿@component
class homeComponent {

}