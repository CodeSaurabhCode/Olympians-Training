﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace ExcepDemo
{
    internal class MyExcep:Exception
    {
        public MyExcep(string msg):base(msg)
        {
            
        }

        public void check()
        {
            try
            {
                Console.WriteLine("Enter the pin");
                string pin = Console.ReadLine();
                if(pin != "1234")
                {
                    throw new MyExcep("Invalid pin");
                }
                try
                {
                    Console.WriteLine("Enter Card expiry date");
                    Console.WriteLine(DateTime.Now);
                    DateTime expdt = Convert.ToDateTime(Console.ReadLine());
                    if (expdt < DateTime.Now)
                    {
                        throw new MyExcep(" Card Expired");
                    }
                
                }
                catch(MyExcep ex)
                {
                    Console.WriteLine( "Card Exception " + ex.Message );
                }

            }
            catch (MyExcep ex)
            {
                Console.WriteLine("Pin Exception "+ ex.Message);
            }
        }

    }
}
