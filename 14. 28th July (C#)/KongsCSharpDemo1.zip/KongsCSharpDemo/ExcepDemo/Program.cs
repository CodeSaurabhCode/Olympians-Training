﻿namespace ExcepDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Exception!");
            MyExcep exobj = new MyExcep("Custom Exception");
            exobj.check();

            try
            {
                //system exception
                int[] arr1 = { 1, 2, 3 };
                Console.WriteLine(arr1[4]);

                try
                {
                    //int n1 = 5;
                    Console.WriteLine("Enter a number");

                }
                catch (Exception ex)
                {
                    Console.WriteLine("From nested catch");
                }
                int n1 = 5;
                Console.WriteLine("Enter a number");
                int n2 = Convert.ToInt32(Console.ReadLine());
                int res = n1 / n2;
                Console.WriteLine(res);
            }
            catch (IndexOutOfRangeException Ix)
            {
                Console.WriteLine("Exception thrown is " + Ix.Message);
                Console.WriteLine("Exception thrown at " + Ix.StackTrace);
            }
            catch (DivideByZeroException Dx)
            {
                Console.WriteLine("Divide Exception thrown is " + Dx.Message);
                Console.WriteLine("Exception thrown at " + Dx.StackTrace);
            }
            catch (Exception ex) 
            {
                Console.WriteLine( "Exception thrown is "+ ex.Message );
                Console.WriteLine("Exception thrown at " + ex.StackTrace);
            }
            
            finally
            {
                Console.WriteLine("At the clean up stage");

            }

            Console.WriteLine(  "After the exception");


        }
    }
}